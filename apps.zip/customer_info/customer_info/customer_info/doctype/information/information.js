// Copyright (c) 2023, mywebsite and contributors
// For license information, please see license.txt

frappe.ui.form.on('Information', {
	// refresh: function(frm) {

	// }
});
