# Copyright (c) 2023, and contributors
# For license information, please see license.txt

import frappe
from frappe.model.document import Document
import calendar

class Calend(Document):
	@frappe.whitelist()
	def validate_dates(self):
		month_index = list(calendar.month_name).index(self.month)
		month_days = calendar.monthcalendar(self.year, month_index)
		day_list = [day for week in month_days for day in week if day != 0]
		for date in day_list:
			date_formatted = f"{date}-{self.month}-{self.year}"
			child = frappe.new_doc("Dates")
			child.update({
				"date": date_formatted,
				"parent": self.name,
				"parenttype": "Calend",
			})
			self.date_available.append(child)



    
			
	
	# def update_dates(self):
	# 	frappe.db.delete('Dates', {'parent': self.name})
	# 	self.create_dates()	


# def after_save(self):
	# 	self.update_dates()
  
	# def find_records(self):	
	# 	count = frappe.db.count("Dates")
	# 	return 1 if count > 0 else 0

	# def validate(self):
	# 	record = self.find_records()
		
	# 	if record == 1:
	# 		user_input = input("Record already exists. Do you want to proceed? (yes/no): ").lower()
	# 		if user_input == 'yes':
	# 			self.update_dates()
	# 	else:
	# 		self.create_dates()

















# import frappe
# from frappe.model.document import Document
# import calendar

# class Calend(Document):
    
# 	def after_save(self):
# 		self.update_dates()

# 	def validate(self):
# 		month_index = list(calendar.month_name).index(self.month)
# 		month_days = calendar.monthcalendar(self.year, month_index)
# 		day_list = [day for week in month_days for day in week if day != 0]

# 		for date in day_list:
# 			child = frappe.new_doc("Dates")
# 			child.update({
# 				"date": f"{date}-{self.month}-{self.year}",
# 				"parent": self.name,
# 				"parenttype": "Calend",
# 			})
# 			self.date_available.append(child)
			
# 	def update_dates(self):
# 		if self.year and self.month:
# 			frappe.db.delete('date_available', {"parent": self.name})
# 			month_index = list(calendar.month_name).index(self.month)
# 			month_days = calendar.monthcalendar(self.year, month_index)
# 			day_list = [day for week in month_days for day in week if day != 0]

# 			for date in day_list:
# 				child = frappe.new_doc("Dates")
# 				child.update({
# 					"date": f"{date}-{self.month}-{self.year}",
# 					"parent": self.name,
# 					"parenttype": "Calend",
# 				})
# 				self.date_available.append(child)

