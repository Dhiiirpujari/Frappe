# Copyright (c) 2023, mywebsite and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestCalend(FrappeTestCase):
	pass
