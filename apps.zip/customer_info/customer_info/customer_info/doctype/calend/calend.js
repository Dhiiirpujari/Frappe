// Copyright (c) 2023, mywebsite and contributors
// For license information, please see license.txt

frappe.ui.form.on('Calend', {
  fetch: function (frm) {
    // frm.set_value('date_available', []);
    // frm.refresh_field('date_available');
    frm.call({
      method: "validate_dates",
      doc: frm.doc,
      callback: function (response) {
        console.log(response);
      },
    //   parent_field: function (frm) {
    //     if (!frm.doc.parent_field) {
    //       frm.set_value('date_available', []);
    //       frm.refresh_field('date_available');
    //     }
    //   },
    });
  },
});
