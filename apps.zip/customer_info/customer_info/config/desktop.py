from frappe import _

def get_data():
	return [
		{
			"module_name": "Customer Info",
			"type": "module",
			"label": _("Customer Info")
		}
	]
