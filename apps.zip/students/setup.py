from setuptools import setup, find_packages

with open("requirements.txt") as f:
	install_requires = f.read().strip().split("\n")

# get version from __version__ variable in students/__init__.py
from students import __version__ as version

setup(
	name="students",
	version=version,
	description="Students data written here",
	author="NEW INDIA",
	author_email="india@stud.com",
	packages=find_packages(),
	zip_safe=False,
	include_package_data=True,
	install_requires=install_requires
)
