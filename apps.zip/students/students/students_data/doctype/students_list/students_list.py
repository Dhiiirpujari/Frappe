# Copyright (c) 2023, NEW INDIA and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document
from students.students_data.doctype.students_list.custom_stud import CustomStudent
class Students_list(Document):
	
	def validate(self):
		self.age = CustomStudent.age(self.dob)
		self.stud_fullname = self.stud_name+" "+self.stud_middlename+" "+self.stud_surname

		CustomStudent.get_marks(self.name)