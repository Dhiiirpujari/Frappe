from datetime import date,datetime
import frappe

class CustomStudent:
    
    @classmethod
    def age(cls,b_date):
        birth_date = datetime.strptime(b_date,"%Y-%m-%d").year
        cur_date = date.today().year
        return cur_date-birth_date
    
    @classmethod
    def get_marks(cls,name):
        data = frappe.get_doc("Students_list",name)
        marks = frappe.get_list("Stud_marks_details",['*'])
        
        for x in data.mks_table:
            child_docs = frappe.get_list("Marks", filters={'name': x.name}, fields=['*'])
            print(child_docs)
            for doc in child_docs:
                history_marks = doc.get('hist_mks')
                math_marks = doc.get('math_mks')
                science_marks = doc.get('sci_mks')
                print(f"History Marks: {history_marks}, Math Marks: {math_marks}, Science Marks: {science_marks}")