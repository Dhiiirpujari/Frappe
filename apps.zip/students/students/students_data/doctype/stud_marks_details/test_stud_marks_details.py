# Copyright (c) 2023, NEW INDIA and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestStud_marks_details(FrappeTestCase):
	pass
