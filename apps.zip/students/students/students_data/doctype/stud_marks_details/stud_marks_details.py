# Copyright (c) 2023, NEW INDIA and contributors
# For license information, please see license.txt

# import frappe
from frappe.model.document import Document

class Stud_marks_details(Document):
	pass
