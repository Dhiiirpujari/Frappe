# Copyright (c) 2023, broking agent and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestAvailable_Spaces(FrappeTestCase):
	pass
