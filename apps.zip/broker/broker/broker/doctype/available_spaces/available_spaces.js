// Copyright (c) 2023, broking agent and contributors
// For license information, please see license.txt

frappe.ui.form.on('Available_Spaces', {
	// refresh: function(frm) {

	// }
});
