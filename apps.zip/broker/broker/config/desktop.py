from frappe import _

def get_data():
	return [
		{
			"module_name": "Broker",
			"type": "module",
			"label": _("Broker")
		}
	]
