from frappe import _

def get_data():
	return [
		{
			"module_name": "Library Department",
			"type": "module",
			"label": _("Library Department")
		}
	]
