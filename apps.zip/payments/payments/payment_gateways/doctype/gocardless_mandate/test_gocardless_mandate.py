# Copyright (c) 2018, Frappe Technologies and Contributors
# See license.txt

import unittest


class TestGoCardlessMandate(unittest.TestCase):
	pass
