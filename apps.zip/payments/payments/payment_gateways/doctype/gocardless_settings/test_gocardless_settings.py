# Copyright (c) 2018, Frappe Technologies and Contributors
# See license.txt

import unittest


class TestGoCardlessSettings(unittest.TestCase):
	pass
