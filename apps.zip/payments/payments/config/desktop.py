from frappe import _


def get_data():
	return [{"module_name": "Payments", "type": "module", "label": _("Payments")}]
