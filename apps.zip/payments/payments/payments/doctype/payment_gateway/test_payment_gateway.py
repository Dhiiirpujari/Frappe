# Copyright (c) 2015, Frappe Technologies Pvt. Ltd. and Contributors
# License: MIT. See LICENSE
import unittest

# test_records = frappe.get_test_records('Payment Gateway')


class TestPaymentGateway(unittest.TestCase):
	pass
