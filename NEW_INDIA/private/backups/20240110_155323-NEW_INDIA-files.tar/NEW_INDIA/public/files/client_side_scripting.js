// Copyright (c) 2023, mywebsite and contributors
// For license information, please see license.txt

// frappe.ui.form.on('Client Side Scripting', {

// 	//     Events in js

// 	// refresh: function(frm) {
// 	// 	// frappe.msgprint("HEllO CODER")
// 	// 	frappe.throw("This is Error in Frappe refresh event")
// 	// }

// 	// onload:function(frm){
// 	// 	frappe.msgprint("Hello onload Event triggered")
// 	// }

// 	// validate:function(frm){
// 	// 	frappe.throw("Validate event triggered")
// 	// }

// 	// before_save:function(frm){
// 	// 	frappe.throw("Before save event triggered")
// 	// }

// 	// after_save:function(frm){
// 	// 	frappe.throw("After Save Event Triggered")
// 	// }

// // field base event triggering when we change values in field (in our case we have enable check box)
// // if we tick that filed it will show pop up 

// 	// enable:function(frm){
// 	// 	frappe.msgprint("From enable event triggered")
// 	// }

// 	// this age event is triggered when we put some value in it and save

// 	// age:function(frm){
// 	// 	frappe.msgprint("This is age filed name event")
// 	// }


// 	// family_members_on_form_rendered:function(frm){
// 	// 	frappe.msgprint("From Family Member child table rendered event")
// 	// }

// 	// before_submit: function(frm) { 
// 	// 	frappe.throw("From before submit Event triggered")
// 	// }

// 	// on_submit:function(frm){
// 	// 	frappe.msgprint("On Submit Event triggered")
// 	// }

// 	// before_cancel:function(frm){
// 	// 	frappe.throw("Before Cancel Event triggered")
// 	// }

// 	// after_cancel:function(frm){
// 	// 	frappe.throw("After Cancel Event triggered")
// 	// }



// 	// Child Table Event trigger

// });

frappe.ui.form.on('Family Members', {

	// this field is triggered when we add row in child table and edit

	// name1: function(frm){
	// 	frappe.msgprint("Child table Field Triggered")
	// }

	// age:function(frm){
	// 	frappe.msgprint("Age fieled triggered from child table whild adding value")
	// }
});




// Accesing doc types 


frappe.ui.form.on('Client Side Scripting', {


});

